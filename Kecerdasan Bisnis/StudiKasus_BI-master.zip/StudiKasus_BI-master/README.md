# StudiKasus_BI
Data Berikut ini merupakan data source yang akan digunakan sebagai contoh studi kasus dalam pembelajaran BI
